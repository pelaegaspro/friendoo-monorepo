// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

const String kWidgetPreviewDtdUri = '';
const String kWidgetPreviewService = 'widget-preview';
const String kWidgetPreviewScaffoldStream = 'WidgetPreviewScaffold';
const String kProjectRootPath = r'';
