import { NextRequest, NextResponse } from 'next/server'
import { ADMIN_COOKIE_NAME, isValidAdminSession } from './lib/admin/session'

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  if (!pathname.startsWith('/admin')) {
    return NextResponse.next()
  }

  const sessionValue = request.cookies.get(ADMIN_COOKIE_NAME)?.value
  const hasSession = isValidAdminSession(sessionValue)
  const isAuthPage = pathname === '/admin/login' || pathname === '/admin/portal'

  if (!hasSession && !isAuthPage) {
    return NextResponse.redirect(new URL('/admin/login', request.url))
  }

  if (hasSession && pathname === '/admin/login') {
    return NextResponse.redirect(new URL('/admin/portal', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/admin/:path*'],
}
