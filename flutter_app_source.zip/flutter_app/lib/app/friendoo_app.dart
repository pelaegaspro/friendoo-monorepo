import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../core/theme/friendoo_theme.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/models/friendoo_models.dart';
import '../core/supabase/supabase_provider.dart';
import '../features/auth/data/auth_repository.dart';
import '../features/calls/application/call_controller.dart';
import '../features/calls/application/host_call_guard.dart';
import '../features/calls/data/call_repository.dart';
import '../features/calls/presentation/call_report_bottom_sheet.dart';
import '../features/calls/presentation/call_summary_dialog.dart';
import '../features/calls/presentation/incoming_host_call_dialog.dart';
import '../features/calls/presentation/live_call_overlay.dart';
import '../features/discover/data/host_repository.dart';
import '../features/presence/data/presence_service.dart';
import '../features/profile/data/profile_repository.dart';
import '../features/profile/presentation/settings_pages.dart';
import '../features/wallet/data/wallet_repository.dart';
import '../features/wallet/presentation/recharge_checkout_sheet.dart';
import 'friendoo_ui.dart';
import '../features/discover/presentation/desi_avatar.dart';

final debugMockSessionProvider = StateProvider<bool>((ref) => false);

class FriendooApp extends StatelessWidget {
  const FriendooApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Friendoo',
      debugShowCheckedModeBanner: false,
      theme: FriendooTheme.light(),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final client = ref.watch(supabaseProvider);
    final debugMockSession = ref.watch(debugMockSessionProvider);
    return StreamBuilder<AuthState>(
      stream: client.auth.onAuthStateChange,
      builder: (context, snapshot) {
        final session = snapshot.data?.session ?? client.auth.currentSession;
        if (!debugMockSession && session == null) return const PhoneAuthPage();
        return const AuthenticatedSession();
      },
    );
  }
}

class PhoneAuthPage extends ConsumerStatefulWidget {
  const PhoneAuthPage({super.key});

  @override
  ConsumerState<PhoneAuthPage> createState() => _PhoneAuthPageState();
}

class _PhoneAuthPageState extends ConsumerState<PhoneAuthPage> {
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  bool _otpRequested = false;
  bool _loading = false;
  String? _error;

  static const _debugMockPhone = '+919000000000';
  static const _debugMockOtp = '123456';

  bool get _isDebugMockPhone =>
      kDebugMode && _phoneController.text.trim() == _debugMockPhone;

  AuthRepository get _auth => AuthRepository(ref.read(supabaseProvider));

  @override
  void dispose() {
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _continue() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      if (_isDebugMockPhone) {
        if (_otpRequested) {
          if (_otpController.text.trim() != _debugMockOtp) {
            throw StateError('Invalid test code');
          }
          ref.read(debugMockSessionProvider.notifier).state = true;
        } else {
          if (mounted) setState(() => _otpRequested = true);
        }
        return;
      }

      if (_otpRequested) {
        await _auth.verifySmsOtp(
          phone: _phoneController.text.trim(),
          code: _otpController.text.trim(),
        );
      } else {
        await _auth.requestSmsOtp(_phoneController.text.trim());
        if (mounted) setState(() => _otpRequested = true);
      }
    } on AuthException catch (error) {
      setState(() => _error = error.message);
    } catch (_) {
      setState(() => _error = 'Unable to continue. Please try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 84,
                      height: 84,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Color(0xFF6366F1),
                            Color(0xFF8B5CF6),
                            Color(0xFFFF2A85),
                          ],
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x406366F1),
                            blurRadius: 24,
                            offset: Offset(0, 10),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.graphic_eq_rounded,
                          color: Colors.white,
                          size: 42,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF6366F1), Color(0xFFFF2A85)],
                        ),
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: const Text(
                        '✦ 100% PRIVATE VOICE CHAT',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Welcome to Friendoo',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF0E1020),
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.8,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Connect instantly with verified female hosts for friendly audio conversations.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF6B7280),
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 32),
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    enabled: !_otpRequested && !_loading,
                    decoration: const InputDecoration(
                      labelText: 'Mobile Phone Number',
                      hintText: '+91 98765 43210',
                      prefixIcon: Icon(Icons.phone_iphone_rounded),
                    ),
                  ),
                  if (_otpRequested) ...[
                    const SizedBox(height: 16),
                    TextField(
                      controller: _otpController,
                      keyboardType: TextInputType.number,
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: '6-Digit SMS Verification Code',
                        hintText: '123456',
                        prefixIcon: Icon(Icons.lock_outline_rounded),
                      ),
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFEE2E2),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFFCA5A5)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline_rounded, color: Color(0xFFDC2626), size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _error!,
                              style: const TextStyle(
                                color: Color(0xFFDC2626),
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
                      ),
                      borderRadius: BorderRadius.circular(99),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x356366F1),
                          blurRadius: 16,
                          offset: Offset(0, 6),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: _loading ? null : _continue,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: const StadiumBorder(),
                      ),
                      child: _loading
                          ? const SizedBox.square(
                              dimension: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              _otpRequested
                                  ? 'Verify & Enter Friendoo Lounge'
                                  : 'Send Instant SMS Code ✦',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.2,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DiscoverPage extends ConsumerStatefulWidget {
  const DiscoverPage({super.key});

  @override
  ConsumerState<DiscoverPage> createState() => _DiscoverPageState();
}

class _DiscoverPageState extends ConsumerState<DiscoverPage> {
  static const _filters = [
    'Tamil',
    'Telugu',
    'Hindi',
    'Malayalam',
    'Kannada',
    'All',
  ];

  late Future<List<HostProfile>> _hosts;
  int _selectedFilter = 0;
  int _currentTabIndex = 0;
  bool _isHostMode = false;

  @override
  void initState() {
    super.initState();
    _hosts = HostRepository(ref.read(supabaseProvider)).fetchAvailableHosts();
  }

  Future<void> _refreshHosts() async {
    setState(() {
      _hosts = HostRepository(ref.read(supabaseProvider)).fetchAvailableHosts();
    });
    await _hosts;
  }

  void _startAudioCall(HostProfile host) {
    ref.read(activeCallProvider.notifier).initiateAudioCall(host.id);
  }

  void _signOut() {
    ref.read(debugMockSessionProvider.notifier).state = false;
    AuthRepository(ref.read(supabaseProvider)).signOut();
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(activeCallProvider, (previous, next) {
      if (next.hasError && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not start call: ${next.error}')),
        );
      }
    });

    ref.listen<LastEndedCallSummary?>(lastEndedCallSummaryProvider, (
      previous,
      next,
    ) {
      if (next != null && mounted) {
        CallSummaryDialog.show(context, next);
      }
    });

    final activeCall = ref.watch(activeCallProvider).asData?.value;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(64),
        child: Container(
          color: Theme.of(context).scaffoldBackgroundColor,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(
                    value: false,
                    label: Text('User flow'),
                    icon: Icon(Icons.person_rounded, size: 16),
                  ),
                  ButtonSegment(
                    value: true,
                    label: Text('Host flow'),
                    icon: Icon(Icons.stars_rounded, size: 16),
                  ),
                ],
                selected: {_isHostMode},
                onSelectionChanged: (set) {
                  setState(() {
                    _isHostMode = set.first;
                    _currentTabIndex = 0;
                  });
                },
              ),
            ],
          ),
        ),
      ),
      bottomSheet: activeCall == null
          ? null
          : LiveCallOverlay(call: activeCall),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentTabIndex,
        onDestinationSelected: (index) {
          setState(() {
            _currentTabIndex = index;
          });
        },
        destinations: _isHostMode
            ? const [
                NavigationDestination(
                  icon: Icon(Icons.dashboard_outlined),
                  selectedIcon: Icon(Icons.dashboard_rounded),
                  label: 'Dashboard',
                ),
                NavigationDestination(
                  icon: Icon(Icons.call_outlined),
                  selectedIcon: Icon(Icons.call_rounded),
                  label: 'Requests',
                ),
                NavigationDestination(
                  icon: Icon(Icons.monetization_on_outlined),
                  selectedIcon: Icon(Icons.monetization_on_rounded),
                  label: 'Earnings',
                ),
                NavigationDestination(
                  icon: Icon(Icons.badge_outlined),
                  selectedIcon: Icon(Icons.badge_rounded),
                  label: 'Host Profile',
                ),
              ]
            : const [
                NavigationDestination(
                  icon: Icon(Icons.explore_outlined),
                  selectedIcon: Icon(Icons.explore_rounded),
                  label: 'Discover',
                ),
                NavigationDestination(
                  icon: Icon(Icons.call_outlined),
                  selectedIcon: Icon(Icons.call_rounded),
                  label: 'Calls',
                ),
                NavigationDestination(
                  icon: Icon(Icons.account_balance_wallet_outlined),
                  selectedIcon: Icon(Icons.account_balance_wallet_rounded),
                  label: 'Wallet',
                ),
                NavigationDestination(
                  icon: Icon(Icons.person_outline_rounded),
                  selectedIcon: Icon(Icons.person_rounded),
                  label: 'Profile',
                ),
              ],
      ),
      body: IndexedStack(
        index: _currentTabIndex,
        children: _isHostMode
            ? [
                const _HostDashboardTab(),
                _CallsTab(onStartCall: _startAudioCall),
                const FriendooHostEarningsView(),
                _ProfileTab(onSignOut: _signOut),
              ]
            : [
                // Tab 0: Discover Lounge
                RefreshIndicator(
                  onRefresh: _refreshHosts,
                  child: FutureBuilder<List<HostProfile>>(
                    future: _hosts,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return _DiscoverMessageState(
                          icon: Icons.wifi_off_rounded,
                          title: 'The host lounge is taking a breath',
                          message: 'Pull down to reconnect and see who is available.',
                          onRetry: _refreshHosts,
                        );
                      }

                      final hosts = snapshot.data ?? const <HostProfile>[];
                      return FriendooDashboardView(
                        hosts: hosts,
                        selectedFilter: _selectedFilter,
                        filters: _filters,
                        onFilterSelected: (index) {
                          setState(() => _selectedFilter = index);
                        },
                        onStartCall: _startAudioCall,
                        onSignOut: _signOut,
                        onOpenActivity: () {
                          setState(() => _currentTabIndex = 1);
                        },
                        onOpenWallet: () {
                          setState(() => _currentTabIndex = 2);
                        },
                      );
                    },
                  ),
                ),
                // Tab 1: Calls History
                FriendooAnalyticsView(
                  onExplore: () {
                    setState(() => _currentTabIndex = 0);
                  },
                  onStartCall: _startAudioCall,
                ),
                // Tab 2: Wallet & Coins Shop
                const FriendooWalletView(),
                // Tab 3: User Profile & Account Settings
                FriendooProfileView(onSignOut: _signOut),
              ],
      ),
    );
  }
}

// ignore: unused_element
class _DiscoverHome extends StatelessWidget {
  const _DiscoverHome({
    required this.hosts,
    required this.filters,
    required this.selectedFilter,
    required this.onFilterSelected,
    required this.onStartCall,
    required this.onSignOut,
  });

  final List<HostProfile> hosts;
  final List<String> filters;
  final int selectedFilter;
  final ValueChanged<int> onFilterSelected;
  final ValueChanged<HostProfile> onStartCall;
  final VoidCallback onSignOut;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final tokens = theme.extension<FriendooDesignTokens>()!;
    final selectedLanguage = filters[selectedFilter];

    final regionalMatches = <HostProfile>[];
    final otherHosts = <HostProfile>[];

    if (selectedLanguage == 'All') {
      regionalMatches.addAll(hosts);
    } else {
      for (final h in hosts) {
        final speaksLang = h.languages.any(
          (l) => l.toLowerCase() == selectedLanguage.toLowerCase(),
        );
        if (speaksLang) {
          regionalMatches.add(h);
        } else {
          otherHosts.add(h);
        }
      }
    }

    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        // Hero Header
        SliverToBoxAdapter(
          child: Container(
            decoration: BoxDecoration(gradient: tokens.heroGradient),
            padding: const EdgeInsets.fromLTRB(20, 54, 20, 28),
            child: SafeArea(
              bottom: false,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Friendoo 🎧',
                          style: theme.textTheme.titleLarge?.copyWith(
                            color: colors.onPrimary,
                            letterSpacing: 0.2,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton.filledTonal(
                        tooltip: 'Sign out',
                        onPressed: onSignOut,
                        icon: const Icon(Icons.logout_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Find your next\nreal conversation.',
                    style: theme.textTheme.displaySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Friendly audio spaces with verified regional-language hosts.',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: colors.onPrimary.withOpacity(0.88),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.25)),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.language_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            selectedLanguage == 'All'
                                ? 'Showing all regional hosts'
                                : 'Showing $selectedLanguage speaking hosts first',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // Regional Language Filter Chips
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 0, 10),
            child: SizedBox(
              height: 42,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: filters.length,
                separatorBuilder: (_, _) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final isSelected = selectedFilter == index;
                  final lang = filters[index];
                  return ChoiceChip(
                    selected: isSelected,
                    label: Text(
                      lang == 'All' ? '🌐 All Languages' : '🗣️ $lang',
                      style: TextStyle(
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.w500,
                      ),
                    ),
                    onSelected: (_) => onFilterSelected(index),
                  );
                },
              ),
            ),
          ),
        ),

        // 1. REGIONAL LANGUAGE MATCHES SECTION (Prioritized First)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        selectedLanguage == 'All'
                            ? 'Available Hosts'
                            : '✨ $selectedLanguage Speaking Hosts (${regionalMatches.length})',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        selectedLanguage == 'All'
                            ? '${regionalMatches.length} verified hosts online'
                            : 'Prioritized at the top based on your language selection',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // Regional Matches List
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate((context, index) {
              final host = regionalMatches[index];
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _HostListCard(
                  host: host,
                  colorIndex: index,
                  preferredLanguage: selectedLanguage,
                  onStartCall: () => onStartCall(host),
                ),
              );
            }, childCount: regionalMatches.length),
          ),
        ),

        // 2. OTHER REGIONAL HOSTS SECTION (Shown below, not filtered out!)
        if (selectedLanguage != 'All' && otherHosts.isNotEmpty) ...[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(),
                  const SizedBox(height: 12),
                  Text(
                    '🌐 Other Available Regional Hosts (${otherHosts.length})',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Also available online (Hindi, Telugu, Malayalam, English & more)',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colors.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((context, index) {
                final host = otherHosts[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _HostListCard(
                    host: host,
                    colorIndex: index + 5,
                    preferredLanguage: selectedLanguage,
                    onStartCall: () => onStartCall(host),
                  ),
                );
              }, childCount: otherHosts.length),
            ),
          ),
        ],

        // Why Friendoo Trust Section
        SliverToBoxAdapter(
          child: Container(
            margin: const EdgeInsets.fromLTRB(20, 16, 20, 28),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: tokens.sectionGradient,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Why Friendoo?',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                const _TrustPoint(
                  icon: Icons.visibility_off_rounded,
                  title: 'Anonymous first',
                  detail: 'Connect without sharing your personal number.',
                ),
                const SizedBox(height: 14),
                const _TrustPoint(
                  icon: Icons.verified_user_rounded,
                  title: 'Verified people',
                  detail: 'Hosts are reviewed before they can go live.',
                ),
                const SizedBox(height: 14),
                const _TrustPoint(
                  icon: Icons.call_end_rounded,
                  title: 'End anytime',
                  detail: 'You stay in control of every conversation.',
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _HostListCard extends StatelessWidget {
  const _HostListCard({
    required this.host,
    required this.colorIndex,
    required this.onStartCall,
    required this.preferredLanguage,
  });

  final HostProfile host;
  final int colorIndex;
  final VoidCallback onStartCall;
  final String preferredLanguage;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final tokens = theme.extension<FriendooDesignTokens>()!;
    final gradient =
        tokens.profileGradients[colorIndex % tokens.profileGradients.length];
    final initial = host.displayName.isEmpty
        ? '?'
        : host.displayName.substring(0, 1).toUpperCase();

    final isRegionalMatch =
        preferredLanguage != 'All' &&
        host.languages.any(
          (l) => l.toLowerCase() == preferredLanguage.toLowerCase(),
        );

    return Card(
      elevation: isRegionalMatch ? 2 : 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: isRegionalMatch
            ? BorderSide(color: colors.primary.withOpacity(0.5), width: 1.5)
            : BorderSide(color: colors.outlineVariant.withOpacity(0.35)),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onStartCall,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Stack(
                  children: [
                    Center(
                      child: Text(
                        initial,
                        style: theme.textTheme.headlineSmall?.copyWith(
                          color: colors.onPrimary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (host.isStar)
                      Positioned(
                        top: 4,
                        left: 4,
                        child: Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: Colors.amber,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: colors.surface,
                              width: 1.5,
                            ),
                          ),
                          child: const Icon(
                            Icons.star_rounded,
                            size: 14,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    Positioned(
                      right: 4,
                      bottom: 4,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981),
                          shape: BoxShape.circle,
                          border: Border.all(color: colors.surface, width: 2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            host.displayName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.amber.withOpacity(0.18),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.star_rounded,
                                color: Colors.amber,
                                size: 14,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                '${host.rating}',
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.amber,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      host.bio ?? 'Ready for a safe audio conversation',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        // Language Chips
                        ...host.languages.map((lang) {
                          final isCurrentLang =
                              lang.toLowerCase() ==
                              preferredLanguage.toLowerCase();
                          return Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: isCurrentLang
                                  ? colors.primary
                                  : colors.primaryContainer.withOpacity(0.5),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              isCurrentLang ? '🗣️ $lang' : lang,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: isCurrentLang
                                    ? Colors.white
                                    : colors.primary,
                              ),
                            ),
                          );
                        }),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: colors.surfaceVariant.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '${host.ratePerAudioMinute} coins/min',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: colors.onSurfaceVariant,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                tooltip: 'Start audio call',
                onPressed: onStartCall,
                icon: const Icon(Icons.call_rounded),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrustPoint extends StatelessWidget {
  const _TrustPoint({
    required this.icon,
    required this.title,
    required this.detail,
  });

  final IconData icon;
  final String title;
  final String detail;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: colors.surface.withOpacity(0.82),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: colors.primary, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: theme.textTheme.labelLarge),
              const SizedBox(height: 2),
              Text(detail, style: theme.textTheme.labelMedium),
            ],
          ),
        ),
      ],
    );
  }
}

class _DiscoverMessageState extends StatelessWidget {
  const _DiscoverMessageState({
    required this.icon,
    required this.title,
    required this.message,
    required this.onRetry,
  });

  final IconData icon;
  final String title;
  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final tokens = theme.extension<FriendooDesignTokens>()!;
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(24),
      children: [
        const SizedBox(height: 120),
        Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: tokens.sectionGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [tokens.softShadow],
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: colors.surface,
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 42, color: colors.primary),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                textAlign: TextAlign.center,
                style: theme.textTheme.headlineSmall,
              ),
              const SizedBox(height: 10),
              Text(
                message,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class ActiveCallBar extends ConsumerWidget {
  const ActiveCallBar({super.key, required this.call});

  final CallSession call;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    return Material(
      elevation: 12,
      shadowColor: colors.primary.withOpacity(0.3),
      child: SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: colors.surface,
            border: Border(
              top: BorderSide(color: colors.outlineVariant.withOpacity(0.4)),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: colors.primaryContainer,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.graphic_eq_rounded,
                  color: colors.primary,
                  size: 22,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Voice Call Connected',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${call.ratePerMinute} coins/min • Live conversation',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: colors.error,
                  foregroundColor: colors.onError,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () =>
                    ref.read(activeCallProvider.notifier).endActiveCall(),
                icon: const Icon(Icons.call_end_rounded, size: 18),
                label: const Text('End Call'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AuthenticatedSession extends ConsumerStatefulWidget {
  const AuthenticatedSession({super.key});

  @override
  ConsumerState<AuthenticatedSession> createState() =>
      _AuthenticatedSessionState();
}

class _AuthenticatedSessionState extends ConsumerState<AuthenticatedSession> {
  PresenceService? _presence;

  @override
  void initState() {
    super.initState();
    _presence = PresenceService(ref.read(supabaseProvider));
    unawaited(_presence!.start());
    // Start background availability checker across full app
    ref.read(backgroundAvailabilityCheckerProvider);
  }

  @override
  void dispose() {
    unawaited(_presence?.stop() ?? Future<void>.value());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) =>
      const IncomingCallListener(child: DiscoverPage());
}

class IncomingCallListener extends ConsumerStatefulWidget {
  const IncomingCallListener({super.key, required this.child});

  final Widget child;

  @override
  ConsumerState<IncomingCallListener> createState() =>
      _IncomingCallListenerState();
}

class _IncomingCallListenerState extends ConsumerState<IncomingCallListener> {
  StreamSubscription<List<CallSession>>? _subscription;
  String? _presentedCallId;

  @override
  void initState() {
    super.initState();
    _subscription = ref
        .read(callRepositoryProvider)
        .watchIncomingCalls()
        .listen(_handleIncomingCalls);
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  void _handleIncomingCalls(List<CallSession> calls) {
    if (!mounted || calls.isEmpty || _presentedCallId != null) return;
    final activeCall = ref.read(activeCallProvider).asData?.value;
    if (activeCall != null) return;

    final call = calls.first;
    final guard = ref.read(hostCallGuardProvider);

    // If host is offline, automatically prevent/reject call
    if (!guard.isOnline) {
      unawaited(
        ref
            .read(callRepositoryProvider)
            .endCall(call.id, reason: 'host_offline'),
      );
      return;
    }

    _presentedCallId = call.id;
    unawaited(_showIncomingCall(call));
  }

  Future<void> _showIncomingCall(CallSession call) async {
    final decision = await IncomingHostCallDialog.show(context, call: call);

    try {
      if (decision == IncomingCallDecision.accept) {
        await ref.read(activeCallProvider.notifier).acceptIncomingCall(call.id);
      } else if (decision == IncomingCallDecision.goOffline) {
        await ref.read(hostCallGuardProvider.notifier).setOnlineStatus(false);
        await ref
            .read(callRepositoryProvider)
            .endCall(call.id, reason: 'host_offline');
      } else {
        // Record skip count for the host
        ref.read(hostCallGuardProvider.notifier).recordSkip();
        await ref
            .read(callRepositoryProvider)
            .endCall(call.id, reason: 'host_skipped');
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('This conversation is no longer active.'),
          ),
        );
      }
    } finally {
      _presentedCallId = null;
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

class _CallsTab extends ConsumerStatefulWidget {
  const _CallsTab({required this.onStartCall});
  final ValueChanged<HostProfile> onStartCall;

  @override
  ConsumerState<_CallsTab> createState() => _CallsTabState();
}

class _CallsTabState extends ConsumerState<_CallsTab> {
  // 0: All Calls, 1: Today, 2: This Week, 3: This Month, 4: Highest Earnings, 5: Longest Calls
  int _selectedFilterIndex = 0;
  bool _isReportMode = false;
  final Set<String> _reportedCallIds = <String>{};

  void _toggleReport(CallHistoryItem call) {
    setState(() {
      if (_reportedCallIds.contains(call.id)) {
        _reportedCallIds.remove(call.id);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFF374151),
            content: Text('Report for ${call.otherPartyName} undone.'),
            duration: const Duration(seconds: 2),
          ),
        );
      } else {
        _reportedCallIds.add(call.id);
        ref.read(callRepositoryProvider).submitCallReport(
          callId: call.id,
          reason: 'Reported by host from call history',
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFFDC2626),
            content: Text('User ${call.otherPartyName} reported to Trust & Safety team.'),
            action: SnackBarAction(
              label: 'Undo',
              textColor: Colors.white,
              onPressed: () => _toggleReport(call),
            ),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final callHistoryAsync = ref.watch(callHistoryProvider);

    return callHistoryAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
        children: [
          _HostCallsHeader(
            onFilter: () => _showHostFilterSheet(context, const []),
            onToggleReportMode: () => setState(() => _isReportMode = !_isReportMode),
            isReportMode: _isReportMode,
          ),
          const SizedBox(height: 24),
          const _EmptyHostCallsSurface(),
        ],
      ),
      data: (allCalls) {
        final now = DateTime.now();

        // Apply transaction & time filters
        List<CallHistoryItem> filtered = List.from(allCalls);
        if (_selectedFilterIndex == 1) {
          // Today
          filtered = filtered.where((c) =>
            c.createdAt.year == now.year &&
            c.createdAt.month == now.month &&
            c.createdAt.day == now.day
          ).toList();
        } else if (_selectedFilterIndex == 2) {
          // This Week (last 7 days)
          filtered = filtered.where((c) => now.difference(c.createdAt).inDays <= 7).toList();
        } else if (_selectedFilterIndex == 3) {
          // This Month
          filtered = filtered.where((c) =>
            c.createdAt.year == now.year &&
            c.createdAt.month == now.month
          ).toList();
        } else if (_selectedFilterIndex == 4) {
          // Highest Earnings
          filtered.sort((a, b) => b.displayEarnedInr.compareTo(a.displayEarnedInr));
        } else if (_selectedFilterIndex == 5) {
          // Longest Calls
          filtered.sort((a, b) => (b.durationSeconds ?? (b.durationMinutes * 60))
              .compareTo(a.durationSeconds ?? (a.durationMinutes * 60)));
        }

        return ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 36),
          children: [
            // ==========================================
            // 1. HOST CALLS HEADER
            // Left: Title "My Calls" + Subtitle "Your call history and earnings"
            // Right: [ Filter ] [ Report ]
            // ==========================================
            _HostCallsHeader(
              onFilter: () => _showHostFilterSheet(context, allCalls),
              onToggleReportMode: () => setState(() => _isReportMode = !_isReportMode),
              isReportMode: _isReportMode,
            ),
            const SizedBox(height: 14),

            // Horizontal Filter Chips (All Calls, Today, This Week, This Month, Highest Earnings, Longest Calls)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _HostFilterChip(
                    label: 'All Calls',
                    selected: _selectedFilterIndex == 0,
                    onTap: () => setState(() => _selectedFilterIndex = 0),
                  ),
                  const SizedBox(width: 8),
                  _HostFilterChip(
                    label: 'Today',
                    selected: _selectedFilterIndex == 1,
                    onTap: () => setState(() => _selectedFilterIndex = 1),
                  ),
                  const SizedBox(width: 8),
                  _HostFilterChip(
                    label: 'This Week',
                    selected: _selectedFilterIndex == 2,
                    onTap: () => setState(() => _selectedFilterIndex = 2),
                  ),
                  const SizedBox(width: 8),
                  _HostFilterChip(
                    label: 'This Month',
                    selected: _selectedFilterIndex == 3,
                    onTap: () => setState(() => _selectedFilterIndex = 3),
                  ),
                  const SizedBox(width: 8),
                  _HostFilterChip(
                    label: 'Highest Earnings',
                    icon: Icons.trending_up_rounded,
                    selected: _selectedFilterIndex == 4,
                    onTap: () => setState(() => _selectedFilterIndex = 4),
                  ),
                  const SizedBox(width: 8),
                  _HostFilterChip(
                    label: 'Longest Calls',
                    icon: Icons.timer_outlined,
                    selected: _selectedFilterIndex == 5,
                    onTap: () => setState(() => _selectedFilterIndex = 5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // ==========================================
            // 2. HOST CALL HISTORY ITEMS (User called Host)
            // ==========================================
            if (filtered.isEmpty)
              const _EmptyHostCallsSurface()
            else
              ...filtered.map(
                (call) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _HostCallHistoryCard(
                    call: call,
                    isReportMode: _isReportMode,
                    isReported: _reportedCallIds.contains(call.id),
                    onToggleReport: () => _toggleReport(call),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  void _showHostFilterSheet(BuildContext context, List<CallHistoryItem> calls) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFE5E7EB),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Filter Call History',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: FriendooUiColors.ink,
              ),
            ),
            const SizedBox(height: 16),
            _HostFilterOptionTile(
              title: 'All Calls',
              subtitle: 'Show all recorded caller sessions',
              selected: _selectedFilterIndex == 0,
              onTap: () {
                setState(() => _selectedFilterIndex = 0);
                Navigator.of(ctx).pop();
              },
            ),
            _HostFilterOptionTile(
              title: 'Today',
              subtitle: 'Calls received today',
              selected: _selectedFilterIndex == 1,
              onTap: () {
                setState(() => _selectedFilterIndex = 1);
                Navigator.of(ctx).pop();
              },
            ),
            _HostFilterOptionTile(
              title: 'This Week',
              subtitle: 'Calls from the past 7 days',
              selected: _selectedFilterIndex == 2,
              onTap: () {
                setState(() => _selectedFilterIndex = 2);
                Navigator.of(ctx).pop();
              },
            ),
            _HostFilterOptionTile(
              title: 'This Month',
              subtitle: 'Calls during the current calendar month',
              selected: _selectedFilterIndex == 3,
              onTap: () {
                setState(() => _selectedFilterIndex = 3);
                Navigator.of(ctx).pop();
              },
            ),
            _HostFilterOptionTile(
              title: 'Highest Earnings',
              subtitle: 'Sorted by amount earned descending',
              selected: _selectedFilterIndex == 4,
              onTap: () {
                setState(() => _selectedFilterIndex = 4);
                Navigator.of(ctx).pop();
              },
            ),
            _HostFilterOptionTile(
              title: 'Longest Calls',
              subtitle: 'Sorted by duration descending',
              selected: _selectedFilterIndex == 5,
              onTap: () {
                setState(() => _selectedFilterIndex = 5);
                Navigator.of(ctx).pop();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _HostCallsHeader extends StatelessWidget {
  const _HostCallsHeader({
    required this.onFilter,
    required this.onToggleReportMode,
    required this.isReportMode,
  });

  final VoidCallback? onFilter;
  final VoidCallback? onToggleReportMode;
  final bool isReportMode;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left: Title & Subtitle
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'My Calls',
                style: TextStyle(
                  color: FriendooUiColors.ink,
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.7,
                  height: 1.15,
                ),
              ),
              SizedBox(height: 4),
              Text(
                'Your call history and earnings',
                style: TextStyle(
                  color: FriendooUiColors.muted,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),

        // Right: [ Filter ] [ Report ]
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // [ Filter ]
            InkWell(
              onTap: onFilter,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.filter_list_rounded, size: 16, color: FriendooUiColors.ink),
                    SizedBox(width: 4),
                    Text(
                      'Filter',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: FriendooUiColors.ink,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),

            // [ Report ] / [ Done ]
            InkWell(
              onTap: onToggleReportMode,
              borderRadius: BorderRadius.circular(12),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: isReportMode ? const Color(0xFFDC2626) : const Color(0xFFFEF2F2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isReportMode ? const Color(0xFFDC2626) : const Color(0xFFFECACA)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isReportMode ? Icons.check_rounded : Icons.shield_outlined,
                      size: 16,
                      color: isReportMode ? Colors.white : const Color(0xFFDC2626),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      isReportMode ? 'Done' : 'Report',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: isReportMode ? Colors.white : const Color(0xFFDC2626),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _HostCallHistoryCard extends StatelessWidget {
  const _HostCallHistoryCard({
    required this.call,
    required this.isReportMode,
    required this.isReported,
    required this.onToggleReport,
  });

  final CallHistoryItem call;
  final bool isReportMode;
  final bool isReported;
  final VoidCallback onToggleReport;

  @override
  Widget build(BuildContext context) {
    final initial = call.otherPartyName.isNotEmpty
        ? call.otherPartyName.substring(0, 1).toUpperCase()
        : 'U';

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isReported
              ? const Color(0xFFFCA5A5)
              : const Color(0xFFE5E7EB),
          width: isReported ? 1.4 : 1.1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.025),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // User Initial / Avatar Placeholder (NO photo)
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFEDE9FE), Color(0xFFE0E7FF)],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFC7D2FE).withOpacity(0.6)),
            ),
            child: Center(
              child: Text(
                initial,
                style: const TextStyle(
                  color: Color(0xFF4F46E5),
                  fontWeight: FontWeight.w900,
                  fontSize: 19,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),

          // Center Information: User Name, City, Date/Time, Duration
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // User Name
                Text(
                  call.otherPartyName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111827),
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 2),

                // City / State
                Row(
                  children: [
                    const Icon(
                      Icons.location_on_outlined,
                      size: 13,
                      color: Color(0xFF6B7280),
                    ),
                    const SizedBox(width: 3),
                    Flexible(
                      child: Text(
                        call.displayCity,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFF6B7280),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),

                // Call Date/Time and Duration
                Row(
                  children: [
                    Text(
                      call.formattedDateTime,
                      style: const TextStyle(
                        color: Color(0xFF4B5563),
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 5),
                    const Text('•', style: TextStyle(color: Color(0xFF9CA3AF), fontSize: 11)),
                    const SizedBox(width: 5),
                    Text(
                      call.formattedDuration,
                      style: const TextStyle(
                        color: Color(0xFF6B7280),
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),

          // Right: If report mode active -> Replace earning with [ Report ] / [ Undo Report ]
          // If normal mode -> Show amount earned badge
          if (isReportMode)
            isReported
                ? OutlinedButton.icon(
                    onPressed: onToggleReport,
                    icon: const Icon(Icons.undo_rounded, size: 14, color: Color(0xFFDC2626)),
                    label: const Text(
                      'Undo',
                      style: TextStyle(
                        color: Color(0xFFDC2626),
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFDC2626)),
                      backgroundColor: const Color(0xFFFEF2F2),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  )
                : FilledButton.icon(
                    onPressed: onToggleReport,
                    icon: const Icon(Icons.shield_outlined, size: 14, color: Colors.white),
                    label: const Text(
                      'Report',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFDC2626),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  )
          else
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '₹${call.displayEarnedInr}',
                  style: const TextStyle(
                    color: Color(0xFF047857),
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 3),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFECFDF5),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3)),
                  ),
                  child: const Text(
                    'Earned',
                    style: TextStyle(
                      color: Color(0xFF047857),
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

class _HostFilterChip extends StatelessWidget {
  const _HostFilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(99),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6.5),
        decoration: BoxDecoration(
          color: selected ? FriendooUiColors.ink : Colors.white,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(
            color: selected ? FriendooUiColors.ink : const Color(0xFFE5E7EB),
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: FriendooUiColors.ink.withOpacity(0.18),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 13, color: selected ? Colors.white : const Color(0xFF6B7280)),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : const Color(0xFF374151),
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HostFilterOptionTile extends StatelessWidget {
  const _HostFilterOptionTile({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFEDE9FE) : const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? FriendooUiColors.blue : const Color(0xFFE5E7EB),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                      color: selected ? FriendooUiColors.blue : FriendooUiColors.ink,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF6B7280),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
              color: selected ? FriendooUiColors.blue : const Color(0xFF9CA3AF),
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyHostCallsSurface extends StatelessWidget {
  const _EmptyHostCallsSurface();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: const Column(
        children: [
          Icon(Icons.phone_in_talk_outlined, size: 42, color: FriendooUiColors.blue),
          SizedBox(height: 12),
          Text(
            'No calls recorded for this filter',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 15.5,
              color: FriendooUiColors.ink,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Go Live from the lounge to receive new incoming user calls.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFF6B7280), fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _WalletTab extends ConsumerStatefulWidget {
  const _WalletTab();

  @override
  ConsumerState<_WalletTab> createState() => _WalletTabState();
}

class _WalletTabState extends ConsumerState<_WalletTab> {
  int _selectedFilterIndex = 0; // 0: All, 1: Medium, 2: Above 800

  String _formatTimeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes.clamp(1, 60)}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final walletAsync = ref.watch(walletStreamProvider);
    final packagesAsync = ref.watch(coinPackagesProvider);
    final transactionsAsync = ref.watch(walletTransactionsProvider);
    final isFirstTimeBuyer =
        ref.watch(isFirstTimeBuyerProvider).asData?.value ?? false;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 54, 20, 32),
      children: [
        // Title Header
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Coin Wallet 🪙',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Top-up coins to start instant voice calls',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
            IconButton.filledTonal(
              tooltip: 'Refresh Balance',
              icon: const Icon(Icons.refresh_rounded, size: 20),
              onPressed: () {
                ref.invalidate(walletStreamProvider);
                ref.invalidate(walletTransactionsProvider);
                ref.invalidate(isFirstTimeBuyerProvider);
              },
            ),
          ],
        ),
        const SizedBox(height: 18),

        // Available Balance Gradient Card
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors.primary,
                const Color(0xFF8B5CF6),
                const Color(0xFFEC4899),
              ],
            ),
            borderRadius: BorderRadius.circular(26),
            boxShadow: [
              BoxShadow(
                color: colors.primary.withOpacity(0.35),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'AVAILABLE BALANCE',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.85),
                      fontWeight: FontWeight.w700,
                      fontSize: 11,
                      letterSpacing: 1.1,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.flash_on_rounded,
                          color: Colors.amber,
                          size: 14,
                        ),
                        SizedBox(width: 4),
                        Text(
                          'Instant Access',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              walletAsync.when(
                data: (w) {
                  final approxMins = (w.coinBalance / 5).floor();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.monetization_on_rounded,
                            color: Colors.amber,
                            size: 40,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            '${w.coinBalance}',
                            style: theme.textTheme.displaySmall?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'Coins',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '≈ $approxMins minutes of voice talk time (at 5 coins/min)',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  );
                },
                loading: () => const Text(
                  '... Coins',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                error: (_, __) => const Text(
                  '50 Coins',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),

        // FIRST-TIME BUYER EXCLUSIVE OFFER BANNER
        if (isFirstTimeBuyer)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF8B5CF6).withOpacity(0.35),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.card_giftcard_rounded,
                    color: Colors.amber,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '🎁 1st Recharge Perk: +50% Extra Coins!',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'First-time buyers receive +50% bonus coins added automatically on any pack.',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        if (isFirstTimeBuyer) const SizedBox(height: 22),

        // Section Title: Recharge Packs
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recharge Coin Packs',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: colors.primaryContainer.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'Rate: 5 coins/min',
                style: TextStyle(
                  color: colors.primary,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Category Filter Chips (All, Medium ₹149-₹699, Above ₹800 Extra Coins)
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              ChoiceChip(
                label: const Text('All Packs'),
                selected: _selectedFilterIndex == 0,
                onSelected: (_) => setState(() => _selectedFilterIndex = 0),
              ),
              const SizedBox(width: 8),
              ChoiceChip(
                label: const Text('Medium Packs (₹149 - ₹699)'),
                selected: _selectedFilterIndex == 1,
                onSelected: (_) => setState(() => _selectedFilterIndex = 1),
              ),
              const SizedBox(width: 8),
              ChoiceChip(
                label: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.bolt_rounded, size: 16, color: Colors.amber),
                    SizedBox(width: 4),
                    Text('Above ₹800 (Extra Coins)'),
                  ],
                ),
                selected: _selectedFilterIndex == 2,
                selectedColor: Colors.amber.withOpacity(0.2),
                onSelected: (_) => setState(() => _selectedFilterIndex = 2),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // Recharge Packages 2-Column Grid
        packagesAsync.when(
          loading: () => const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(),
            ),
          ),
          error: (_, __) => const SizedBox.shrink(),
          data: (packages) {
            var filtered = packages.where((p) => p.amountInr < 1000).toList();

            if (_selectedFilterIndex == 1) {
              filtered = filtered
                  .where((p) => p.amountInr >= 149 && p.amountInr <= 699)
                  .toList();
            } else if (_selectedFilterIndex == 2) {
              filtered = filtered.where((p) => p.amountInr >= 800).toList();
            }

            return LayoutBuilder(
              builder: (context, constraints) {
                final itemWidth = (constraints.maxWidth - 12) / 2;
                return Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: filtered.map((pkg) {
                    final isAbove800 = pkg.amountInr >= 800;
                    final isSpecial =
                        pkg.bonus != null &&
                        (isAbove800 ||
                            pkg.bonus!.contains('Popular') ||
                            pkg.bonus!.contains('Best Value') ||
                            pkg.bonus!.contains('VIP'));
                    final approxMins = (pkg.coins / 5).round();

                    return SizedBox(
                      width: itemWidth,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () =>
                            RechargeCheckoutSheet.show(context, package: pkg),
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: isAbove800
                                ? Colors.amber.withOpacity(0.06)
                                : isSpecial
                                ? colors.primary.withOpacity(0.05)
                                : colors.surfaceVariant.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isAbove800
                                  ? Colors.amber.withOpacity(0.7)
                                  : isSpecial
                                  ? colors.primary
                                  : colors.outlineVariant.withOpacity(0.35),
                              width: isAbove800
                                  ? 1.8
                                  : isSpecial
                                  ? 1.5
                                  : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Badge or Tag
                              if (pkg.bonus != null) ...[
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 3,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isAbove800
                                        ? Colors.amber[800]
                                        : isSpecial
                                        ? colors.primary
                                        : colors.secondaryContainer,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    pkg.bonus!,
                                    style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.bold,
                                      color: isAbove800 || isSpecial
                                          ? Colors.white
                                          : colors.onSecondaryContainer,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(height: 8),
                              ] else
                                const SizedBox(height: 20),

                              // Coins & Icon
                              Row(
                                children: [
                                  const Icon(
                                    Icons.monetization_on_rounded,
                                    color: Colors.amber,
                                    size: 22,
                                  ),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      '${pkg.coins} Coins',
                                      style: theme.textTheme.titleMedium
                                          ?.copyWith(
                                            fontWeight: FontWeight.bold,
                                          ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),

                              // Estimated Talk Time
                              Text(
                                '≈ $approxMins mins talk time',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: colors.onSurfaceVariant,
                                  fontSize: 11,
                                ),
                              ),
                              const SizedBox(height: 12),

                              // Price Button
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton(
                                  style: FilledButton.styleFrom(
                                    backgroundColor: isAbove800
                                        ? Colors.amber[800]
                                        : isSpecial
                                        ? colors.primary
                                        : colors.secondary,
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 8,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                  onPressed: () => RechargeCheckoutSheet.show(
                                    context,
                                    package: pkg,
                                  ),
                                  child: Text(
                                    '₹${pkg.amountInr}',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            );
          },
        ),

        const SizedBox(height: 28),

        // Section Title: Transaction History
        Text(
          'Recent Wallet Activity',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),

        // Transactions List
        transactionsAsync.when(
          loading: () => const Center(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: CircularProgressIndicator(),
            ),
          ),
          error: (_, __) => const SizedBox.shrink(),
          data: (transactions) {
            if (transactions.isEmpty) {
              return Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: colors.surfaceVariant.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Text(
                    'No wallet transactions yet',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colors.onSurfaceVariant,
                    ),
                  ),
                ),
              );
            }

            return Column(
              children: transactions.take(6).map((tx) {
                final isCredit = tx.coinAmount > 0;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: colors.surfaceVariant.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: isCredit
                                ? Colors.green.withOpacity(0.15)
                                : Colors.redAccent.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isCredit
                                ? Icons.add_circle_outline_rounded
                                : Icons.call_made_rounded,
                            color: isCredit ? Colors.green : Colors.redAccent,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                tx.description ??
                                    (isCredit
                                        ? 'Coin Recharge'
                                        : 'Audio Call Debit'),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                _formatTimeAgo(tx.createdAt),
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: colors.onSurfaceVariant,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          isCredit
                              ? '+${tx.coinAmount} 🪙'
                              : '${tx.coinAmount} 🪙',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: isCredit ? Colors.green : Colors.redAccent,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),

        const SizedBox(height: 24),

        // Security Guarantee Footer
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: colors.surfaceVariant.withOpacity(0.3),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Icon(
                Icons.verified_user_rounded,
                color: Colors.green[700],
                size: 20,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  '100% Anonymous & Secure • Instant Coin Credits • Powered by Cashfree',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colors.onSurfaceVariant,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ProfileTab extends ConsumerWidget {
  const _ProfileTab({required this.onSignOut});
  final VoidCallback onSignOut;

  void _confirmSignOut(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text(
          'Sign out of Host Account?',
          style: TextStyle(fontWeight: FontWeight.w900, color: FriendooUiColors.ink),
        ),
        content: const Text('Are you sure you want to log out of your Friendoo Host account?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF6B7280), fontWeight: FontWeight.w700)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: FriendooUiColors.pink,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              onSignOut();
            },
            child: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileRepo = ref.watch(profileRepositoryProvider);
    final hostStatsAsync = ref.watch(hostDashboardStatsProvider);

    return StreamBuilder<UserProfile?>(
      stream: profileRepo.watchCurrentUserProfile(),
      builder: (context, snapshot) {
        final profile = snapshot.data;
        final hostName = profile?.displayName ?? 'Priya Sharma';
        final languages = profile?.preferredLanguages.isNotEmpty == true
            ? profile!.preferredLanguages
            : const <String>['Tamil', 'Hindi', 'English'];

        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 36),
          children: [
            // Category Chip
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFEF3C7),
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(color: const Color(0xFFFFB703).withOpacity(0.5)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.stars_rounded, size: 14, color: Color(0xFFD97706)),
                      SizedBox(width: 5),
                      Text(
                        'HOST PARTNER PROFILE',
                        style: TextStyle(
                          color: Color(0xFFB45309),
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Host Profile & Settings',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                color: FriendooUiColors.ink,
                letterSpacing: -0.8,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Manage your host profile, payouts, earnings preferences, and performance insights.',
              style: TextStyle(color: Color(0xFF6B7280), fontSize: 12.5, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 20),

            // 1. Female Host Profile Card (With DesiFemaleAvatar, Star Host Badge, Host ID, Languages)
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: const Color(0xFFFFB703).withOpacity(0.6),
                  width: 1.8,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x14FFB703),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Row(
                    children: [
                      // Female Desi Avatar
                      DesiFemaleAvatar(
                        seed: hostName,
                        age: 24,
                        isStar: true,
                        size: 74,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    hostName,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: FriendooUiColors.ink,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: -0.3,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                const Icon(
                                  Icons.verified_rounded,
                                  color: Color(0xFF10B981),
                                  size: 16,
                                ),
                              ],
                            ),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                const Text(
                                  '24 yrs',
                                  style: TextStyle(
                                    color: Color(0xFF4B5563),
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFFFFB703), Color(0xFFFF5400)],
                                    ),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '⭐ Star Host',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF3F4F6),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    'HOST-8391',
                                    style: TextStyle(
                                      color: Color(0xFF6B7280),
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              languages.join(' · '),
                              style: const TextStyle(
                                color: FriendooUiColors.violet,
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Edit Profile Button
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const EditHostProfilePage(),
                          ),
                        );
                      },
                      icon: const Icon(Icons.edit_outlined, size: 16),
                      label: const Text('Edit Host Profile', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: FriendooUiColors.ink,
                        side: const BorderSide(color: Color(0xFFE5E7EB)),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 2. Host Quick Performance Overview (Compact Clean 3-Metric Summary)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text('Rating', style: TextStyle(color: Color(0xFF6B7280), fontSize: 11, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 2),
                        const Text('⭐ 4.9', style: TextStyle(color: FriendooUiColors.ink, fontSize: 16, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 1),
                        const Text('142 reviews', style: TextStyle(color: Color(0xFF9CA3AF), fontSize: 10)),
                      ],
                    ),
                  ),
                  Container(height: 36, width: 1, color: const Color(0xFFE5E7EB)),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text('Calls Done', style: TextStyle(color: Color(0xFF6B7280), fontSize: 11, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 2),
                        Text(
                          hostStatsAsync.when(
                            data: (s) => '${s.totalCallsCount}+',
                            loading: () => '150+',
                            error: (_, __) => '150+',
                          ),
                          style: const TextStyle(color: Color(0xFF10B981), fontSize: 16, fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 1),
                        const Text('Completed', style: TextStyle(color: Color(0xFF9CA3AF), fontSize: 10)),
                      ],
                    ),
                  ),
                  Container(height: 36, width: 1, color: const Color(0xFFE5E7EB)),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text('Views', style: TextStyle(color: Color(0xFF6B7280), fontSize: 11, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 2),
                        const Text('1.4k', style: TextStyle(color: FriendooUiColors.blue, fontSize: 16, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 1),
                        const Text('This month', style: TextStyle(color: Color(0xFF9CA3AF), fontSize: 10)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 3. HOST & ACCOUNT SECTION
            const Text(
              'HOST & ACCOUNT',
              style: TextStyle(
                color: Color(0xFF4B5563),
                fontSize: 12.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
            ),
            const SizedBox(height: 12),

            // 1. Host Information
            _HostNavigationRow(
              icon: Icons.badge_outlined,
              iconBg: const Color(0xFFEDE9FE),
              iconColor: const Color(0xFF7C3AED),
              title: 'Host Information',
              subtitle: 'Voice intro, profession, education & hobbies',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const HostInformationPage(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 2. Payout & Bank Details
            _HostNavigationRow(
              icon: Icons.account_balance_wallet_outlined,
              iconBg: const Color(0xFFECFDF5),
              iconColor: const Color(0xFF059669),
              title: 'Payout & Bank Details',
              subtitle: 'UPI ID, bank account & settlement schedule',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const HostPayoutBankDetailsPage(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 3. Call & Earnings Preferences
            _HostNavigationRow(
              icon: Icons.tune_rounded,
              iconBg: const Color(0xFFFEF3C7),
              iconColor: const Color(0xFFD97706),
              title: 'Call & Earnings Preferences',
              subtitle: 'Per-minute audio rate & priority call alerts',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const HostCallEarningsPreferencesPage(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 4. Performance Insights
            _HostNavigationRow(
              icon: Icons.insights_rounded,
              iconBg: const Color(0xFFE0F2FE),
              iconColor: const Color(0xFF0284C7),
              title: 'Performance Insights',
              subtitle: 'Caller analytics, ratings & duration trends',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const HostPerformanceInsightsPage(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 5. Languages
            _HostNavigationRow(
              icon: Icons.translate_rounded,
              iconBg: const Color(0xFFFDF2F8),
              iconColor: const Color(0xFFDB2777),
              title: 'Languages',
              subtitle: 'Add or update languages you talk with callers in',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const UserLanguagesPage(isHost: true),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 6. Help & Support
            _HostNavigationRow(
              icon: Icons.headset_mic_outlined,
              iconBg: const Color(0xFFF3F4F6),
              iconColor: FriendooUiColors.ink,
              title: 'Help & Support',
              subtitle: 'Host safety guidelines & 24/7 host partner care',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const HelpSupportPage(isHost: true),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 7. About Friendoo
            _HostNavigationRow(
              icon: Icons.info_outline_rounded,
              iconBg: const Color(0xFFF1F5F9),
              iconColor: const Color(0xFF475569),
              title: 'About Friendoo',
              subtitle: 'Host partner terms, safety policy & version',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const AboutFriendooPage(isHost: true),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // 8. Edit Profile
            _HostNavigationRow(
              icon: Icons.person_outline_rounded,
              iconBg: const Color(0xFFF5F3FF),
              iconColor: const Color(0xFF6366F1),
              title: 'Edit Profile',
              subtitle: 'Photo, display name, age & voice intro',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const EditHostProfilePage(),
                  ),
                );
              },
            ),
            const SizedBox(height: 24),

            // Sign Out Button
            OutlinedButton.icon(
              onPressed: () => _confirmSignOut(context),
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Sign out of Host Account'),
              style: OutlinedButton.styleFrom(
                foregroundColor: FriendooUiColors.pink,
                side: const BorderSide(color: Color(0xFFFFD1DC), width: 1.5),
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// Host Navigation Row
class _HostNavigationRow extends StatelessWidget {
  const _HostNavigationRow({
    required this.icon,
    required this.iconBg,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final Color iconBg;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: iconBg,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: FriendooUiColors.ink,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF6B7280),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFF9CA3AF),
                size: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HostDashboardTab extends ConsumerStatefulWidget {
  const _HostDashboardTab();

  @override
  ConsumerState<_HostDashboardTab> createState() => _HostDashboardTabState();
}

class _HostDashboardTabState extends ConsumerState<_HostDashboardTab> {
  bool? _isOnlineLocal;

  static const _hostPromoItems = [
    FriendooPromoItem(
      title: 'BOOST YOUR PROFILE',
      highlight: 'Get More Visibility',
      subtitle: 'Higher placement in caller discovery searches',
      badge: 'GROWTH 🚀',
      gradient: LinearGradient(
        colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      icon: Icons.rocket_launch_rounded,
    ),
    FriendooPromoItem(
      title: 'NEW OPPORTUNITIES',
      highlight: 'High Caller Demand',
      subtitle: 'Users are actively looking for friendly hosts right now',
      badge: 'DEMAND ⚡',
      gradient: LinearGradient(
        colors: [Color(0xFFFFB703), Color(0xFFFF5400)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      icon: Icons.phone_in_talk_rounded,
    ),
    FriendooPromoItem(
      title: 'EARN MORE',
      highlight: 'Peak Hours Bonus',
      subtitle: 'Stay available during peak hours (8 PM – 12 AM)',
      badge: 'PEAK HOURS 💰',
      gradient: LinearGradient(
        colors: [Color(0xFF10B981), Color(0xFF047857)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      icon: Icons.trending_up_rounded,
    ),
    FriendooPromoItem(
      title: 'PRIVACY & SAFETY',
      highlight: 'Your Safety Matters',
      subtitle: 'Caller phone numbers are 100% masked and private',
      badge: 'SECURITY 🛡️',
      gradient: LinearGradient(
        colors: [Color(0xFF141738), Color(0xFF4338CA)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      icon: Icons.verified_user_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final statsAsync = ref.watch(hostDashboardStatsProvider);
    final profileAsync = ref
        .watch(profileRepositoryProvider)
        .watchCurrentUserProfile();

    return StreamBuilder<UserProfile?>(
      stream: profileAsync,
      builder: (context, profileSnap) {
        final hostName = profileSnap.data?.displayName ?? 'Ananya S';
        final userProfile = profileSnap.data;
        final languages = userProfile?.preferredLanguages ?? const ['Tamil', 'English'];

        return statsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const Center(
            child: Text(
              'Unable to load host dashboard',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          data: (stats) {
            final guard = ref.watch(hostCallGuardProvider);
            final isOnline = _isOnlineLocal ?? guard.isOnline;

            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 36),
              children: [
                // ==========================================
                // 1. HOST FLOW HEADER
                // Left: Friendoo Logo + Live / Offline Status Pill
                // Right: Host earnings / balance, Notification icon, Profile/avatar
                // ==========================================
                Row(
                  children: [
                    const FriendooLogo(fontSize: 21),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                      decoration: BoxDecoration(
                        color: isOnline ? const Color(0xFFECFDF5) : const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(
                          color: isOnline
                              ? const Color(0xFF10B981).withOpacity(0.35)
                              : const Color(0xFFD1D5DB),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.circle_rounded,
                            color: isOnline ? const Color(0xFF10B981) : const Color(0xFF9CA3AF),
                            size: 6.5,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            isOnline ? 'Live' : 'Offline',
                            style: TextStyle(
                              color: isOnline ? const Color(0xFF047857) : const Color(0xFF6B7280),
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),

                    // Host Earnings Pill
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: FriendooUiColors.softGold,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFFFFD166).withOpacity(0.6)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.currency_rupee_rounded, color: Color(0xFFD97706), size: 15),
                          const SizedBox(width: 2),
                          Text(
                            '${stats.todayEarningsInr}',
                            style: const TextStyle(
                              color: Color(0xFFB45309),
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),

                    // Notification Icon
                    IconButton(
                      icon: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          const Icon(Icons.notifications_none_rounded, color: FriendooUiColors.ink, size: 23),
                          Positioned(
                            right: 0,
                            top: 0,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: FriendooUiColors.pink,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        ],
                      ),
                      tooltip: 'Notifications',
                      onPressed: () => showFriendooNotificationsSheet(context),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // ==========================================
                // 2. HOST DISCOVER TITLE
                // "Your Voice Lounge"
                // "Manage your availability and see what's happening"
                // ==========================================
                const Text(
                  'Your Voice Lounge',
                  style: TextStyle(
                    color: FriendooUiColors.ink,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.8,
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Manage your availability and see what\'s happening',
                  style: TextStyle(
                    color: FriendooUiColors.muted,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 18),

                // ==========================================
                // 3. HOST STATUS CARD (LIVE / OFFLINE)
                // ==========================================
                Container(
                  decoration: BoxDecoration(
                    color: isOnline ? const Color(0xFFECFDF5) : Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: isOnline ? const Color(0xFF10B981) : const Color(0xFFE5E7EB),
                      width: isOnline ? 2.0 : 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isOnline
                            ? const Color(0x1F10B981)
                            : Colors.black.withOpacity(0.03),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: isOnline ? const Color(0xFF10B981) : const Color(0xFF9CA3AF),
                                  shape: BoxShape.circle,
                                  boxShadow: isOnline
                                      ? [
                                          BoxShadow(
                                            color: const Color(0xFF10B981).withOpacity(0.6),
                                            blurRadius: 8,
                                            spreadRadius: 2,
                                          ),
                                        ]
                                      : null,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                isOnline ? 'YOU ARE LIVE' : 'YOU ARE OFFLINE',
                                style: TextStyle(
                                  color: isOnline ? const Color(0xFF047857) : const Color(0xFF4B5563),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: FriendooUiColors.softBlue,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '₹${stats.ratePerMinute} / min',
                              style: const TextStyle(
                                color: FriendooUiColors.blue,
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        isOnline
                            ? 'Available for incoming voice calls from users.'
                            : 'You\'re currently unavailable to callers.',
                        style: const TextStyle(
                          color: Color(0xFF6B7280),
                          fontSize: 13.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Prominent CTA: Go Offline / Go Live
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () async {
                            final newStatus = !isOnline;
                            setState(() => _isOnlineLocal = newStatus);
                            await ref
                                .read(hostCallGuardProvider.notifier)
                                .setOnlineStatus(newStatus);
                            ref.invalidate(hostDashboardStatsProvider);
                          },
                          icon: Icon(
                            isOnline ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
                            size: 20,
                          ),
                          label: Text(
                            isOnline ? 'Go Offline' : 'Go Live',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          style: FilledButton.styleFrom(
                            backgroundColor: isOnline ? const Color(0xFFDC2626) : const Color(0xFF10B981),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            elevation: 3,
                          ),
                        ),
                      ),

                      // Daily Skip Quota Status (Retaining Host Call Guard logic)
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: guard.mustAutoAttend
                              ? const Color(0xFFFEF3C7)
                              : Colors.black.withOpacity(0.03),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              guard.mustAutoAttend
                                  ? Icons.bolt_rounded
                                  : Icons.shield_rounded,
                              color: guard.mustAutoAttend
                                  ? const Color(0xFFB45309)
                                  : FriendooUiColors.violet,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                guard.mustAutoAttend
                                    ? 'Auto-attend active (0 skips left today)'
                                    : '${guard.remainingSkips} skips remaining today',
                                style: TextStyle(
                                  color: guard.mustAutoAttend
                                      ? const Color(0xFF92400E)
                                      : const Color(0xFF374151),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),

                // ==========================================
                // 4. HOST QUICK STATS (Compact Clean Cards)
                // Today's Calls, Today's Earnings, Avg Duration, Rating
                // ==========================================
                Row(
                  children: [
                    Expanded(
                      child: _HostStatCard(
                        label: 'Today\'s Calls',
                        value: '${stats.todayCallsCount}',
                        unit: 'Calls',
                        icon: Icons.phone_in_talk_rounded,
                        tint: FriendooUiColors.softBlue,
                        iconColor: FriendooUiColors.blue,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _HostStatCard(
                        label: 'Today\'s Earnings',
                        value: '₹${stats.todayEarningsInr}',
                        unit: 'Earned',
                        icon: Icons.monetization_on_rounded,
                        tint: FriendooUiColors.softGold,
                        iconColor: const Color(0xFFD97706),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Row(
                  children: [
                    Expanded(
                      child: _HostStatCard(
                        label: 'Avg Call Duration',
                        value: '8m 24s',
                        unit: 'Per session',
                        icon: Icons.timer_outlined,
                        tint: FriendooUiColors.softViolet,
                        iconColor: FriendooUiColors.violet,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _HostStatCard(
                        label: 'Rating',
                        value: '⭐ 4.9',
                        unit: 'Caller score',
                        icon: Icons.star_rounded,
                        tint: FriendooUiColors.softPink,
                        iconColor: FriendooUiColors.pink,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // ==========================================
                // 5. HOST PROMOTIONAL / INFORMATION CAROUSEL
                // ==========================================
                const FriendooPromoCarousel(items: _hostPromoItems),
                const SizedBox(height: 24),

                // ==========================================
                // 6. HOST DISCOVERY / RECENT ACTIVITY
                // ==========================================
                const Text(
                  'Recent Activity',
                  style: TextStyle(
                    color: FriendooUiColors.ink,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 12),
                const _HostActivityTile(
                  title: 'User requested a voice call',
                  timeAgo: '2 min ago',
                  icon: Icons.phone_callback_rounded,
                  tint: FriendooUiColors.softBlue,
                  iconColor: FriendooUiColors.blue,
                ),
                const SizedBox(height: 10),
                const _HostActivityTile(
                  title: 'User completed a 12-minute call',
                  timeAgo: '8 min ago',
                  icon: Icons.check_circle_rounded,
                  tint: Color(0xFFECFDF5),
                  iconColor: Color(0xFF10B981),
                ),
                const SizedBox(height: 10),
                const _HostActivityTile(
                  title: 'New profile view from Discover',
                  timeAgo: '15 min ago',
                  icon: Icons.visibility_rounded,
                  tint: FriendooUiColors.softViolet,
                  iconColor: FriendooUiColors.violet,
                ),
                const SizedBox(height: 10),
                const _HostActivityTile(
                  title: 'Caller from Bangalore added you to favorites',
                  timeAgo: '35 min ago',
                  icon: Icons.favorite_rounded,
                  tint: FriendooUiColors.softPink,
                  iconColor: FriendooUiColors.pink,
                ),
                const SizedBox(height: 24),

                // ==========================================
                // 7. HOST PROFILE CARD (Desi Avatar + Age + Badges + Languages)
                // ==========================================
                const Text(
                  'Host Profile',
                  style: TextStyle(
                    color: FriendooUiColors.ink,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: const Color(0xFFFFB703).withOpacity(0.55),
                      width: 1.8,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0x14FFB703),
                        blurRadius: 16,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(18),
                  child: Row(
                    children: [
                      // Host's Desi Avatar (NO age badge on avatar)
                      DesiFemaleAvatar(
                        seed: hostName,
                        age: 24,
                        isStar: true,
                        size: 68,
                        showPresence: true,
                        isOnline: isOnline,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    hostName,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: FriendooUiColors.ink,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: -0.3,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                const Icon(
                                  Icons.verified_rounded,
                                  color: Color(0xFF10B981),
                                  size: 16,
                                ),
                              ],
                            ),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                const Text(
                                  '24 yrs',
                                  style: TextStyle(
                                    color: Color(0xFF4B5563),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFFFFB703), Color(0xFFFF5400)],
                                    ),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '⭐ Star Host',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              languages.join(' · '),
                              style: const TextStyle(
                                color: FriendooUiColors.violet,
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // ==========================================
                // 8. HOST CTA: Primary [Go Offline/Live] + Secondary [Edit Profile]
                // ==========================================
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: FilledButton(
                        onPressed: () async {
                          final newStatus = !isOnline;
                          setState(() => _isOnlineLocal = newStatus);
                          await ref
                              .read(hostCallGuardProvider.notifier)
                              .setOnlineStatus(newStatus);
                          ref.invalidate(hostDashboardStatsProvider);
                        },
                        style: FilledButton.styleFrom(
                          backgroundColor: isOnline ? const Color(0xFFDC2626) : const Color(0xFF10B981),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: Text(
                          isOnline ? 'Go Offline' : 'Go Live',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: OutlinedButton(
                        onPressed: () {
                          showFriendooLanguagePicker(
                            context,
                            selectedLanguages: languages,
                            isHost: true,
                            onSave: (langs) async {
                              await ref
                                  .read(hostRepositoryProvider)
                                  .updateCurrentHostLanguages(langs);
                              ref.invalidate(profileRepositoryProvider);
                            },
                          );
                        },
                        style: OutlinedButton.styleFrom(
                          foregroundColor: FriendooUiColors.ink,
                          side: const BorderSide(color: Color(0xFFD1D5DB), width: 1.5),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          'Edit Profile',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // ==========================================
                // 9. INCOMING CALL REQUESTS (Live Queue)
                // ==========================================
                Consumer(
                  builder: (context, ref, _) {
                    final incomingStream = ref
                        .watch(callRepositoryProvider)
                        .watchIncomingCalls();
                    return StreamBuilder<List<CallSession>>(
                      stream: incomingStream,
                      builder: (context, snap) {
                        final calls = snap.data ?? [];
                        if (calls.isEmpty) return const SizedBox.shrink();

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Live Incoming Calls',
                              style: TextStyle(
                                color: FriendooUiColors.ink,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 12),
                            ...calls.map((c) {
                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(color: const Color(0xFF10B981), width: 1.5),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0x1810B981),
                                      blurRadius: 12,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    const CircleAvatar(
                                      radius: 20,
                                      backgroundColor: FriendooUiColors.violet,
                                      child: Icon(
                                        Icons.person_rounded,
                                        color: Colors.white,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Incoming ${c.callType.name.toUpperCase()} Call',
                                            style: const TextStyle(
                                              color: FriendooUiColors.ink,
                                              fontSize: 15,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            'Rate: ₹${c.ratePerMinute} / min',
                                            style: const TextStyle(
                                              color: FriendooUiColors.muted,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    FilledButton(
                                      style: FilledButton.styleFrom(
                                        backgroundColor: const Color(0xFF10B981),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                      ),
                                      onPressed: () => ref
                                          .read(activeCallProvider.notifier)
                                          .acceptIncomingCall(c.id),
                                      child: const Text('Accept'),
                                    ),
                                  ],
                                ),
                              );
                            }),
                          ],
                        );
                      },
                    );
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _HostStatCard extends StatelessWidget {
  const _HostStatCard({
    required this.label,
    required this.value,
    required this.unit,
    required this.icon,
    required this.tint,
    required this.iconColor,
  });

  final String label;
  final String value;
  final String unit;
  final IconData icon;
  final Color tint;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: FriendooUiColors.muted,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: tint,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: iconColor, size: 16),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              color: FriendooUiColors.ink,
              fontSize: 20,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            unit,
            style: const TextStyle(
              color: Color(0xFF9CA3AF),
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _HostActivityTile extends StatelessWidget {
  const _HostActivityTile({
    required this.title,
    required this.timeAgo,
    required this.icon,
    required this.tint,
    required this.iconColor,
  });

  final String title;
  final String timeAgo;
  final IconData icon;
  final Color tint;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: tint,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: FriendooUiColors.ink,
                fontSize: 13.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            timeAgo,
            style: const TextStyle(
              color: Color(0xFF9CA3AF),
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _HostEarningsTab extends StatelessWidget {
  const _HostEarningsTab();

  @override
  Widget build(BuildContext context) {
    return const FriendooHostEarningsView();
  }
}

